package characterstream2;

public class CharacterStream2 {

    public static void main(String[] args) {
        
    }
    
}
